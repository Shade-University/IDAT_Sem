INSERT INTO ST55431.SKUPINY (ID_SKUPINA, NAZEV, POPIS) VALUES (1, 'Skupina: První ročník', 'Skupina prváků');
INSERT INTO ST55431.SKUPINY (ID_SKUPINA, NAZEV, POPIS) VALUES (2, 'Skupina: Druhý ročník', 'Skupina druháci');
INSERT INTO ST55431.SKUPINY (ID_SKUPINA, NAZEV, POPIS) VALUES (3, 'Skupina: Třetí ročník', 'Skupina třeťáci');
INSERT INTO ST55431.SKUPINY (ID_SKUPINA, NAZEV, POPIS) VALUES (4, 'Skupina: Pátý ročník', 'Skupina páťáků');